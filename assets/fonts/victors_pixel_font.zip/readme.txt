Thank you for downloading Victor's Pixel Font v1.0 for Windows (and whatever other system that will use it).

This font is provided free, as-is, with NO WARRANTIES of any kind. This font is unsupported, so please DO NOT contact me with questions on how to install this font under Windows or Macintosh (if it even works for Mac). You may contact me ONLY if you have bug reports for the font itself or perhaps a suggestion.

* To install this font under Windows 7:

1. Unzip the font itself to the folder of your choice.

2. Right-click the file and select Install.

3. Follow the prompts if any.

* To install this font under Windows XP:

1. Unzip the font itself to the folder of your choice.

2. Go to your Control Panel via the Start Menu.

2-a. If you are in Category View, click on "Switch to Classic View" on the far LEFT side of the window.

3. Double-click on "Fonts". This will open up your Fonts folder.

4. Click on the File Menu, and then "Install New Font...". This will open the Add Fonts dialog.

5. Under the little folder view on the bottom-left, browse to the folder the font was unzipped to. If you unzipped this to your My Documents folder or your Desktop, the font will be located in "C:\Documents and Settings", under the folder labelled as your user name, and then either the "My Documents" or "Desktop" folder. You may have to double-click the "c:\" icon in the browse box to see the Documents and Settings folder.

6. After successfully browsing to the location of the font(s) you wish to install, the list box above that will list all fonts you have in that folder. Click on Victor's Pixel Font, MAKE SURE that "Copy fonts to fonts folder" is checked at the bottom, and then click on OK.

With success the font will install. If you are running any programs such as Photoshop or Word while installing the font, you MUST restart them so it will see it.

If you have any problems, feel free to instant-message me via AIM/ICQ or Yahoo:
AIM/Yahoo: SergeantKoopa
ICQ: 42690399

Enjoy!

 - K